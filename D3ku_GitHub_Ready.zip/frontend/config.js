const BACKEND_URL = 'https://YOUR_BACKEND_URL'; // remplace par l’URL publique Replit (ex: https://ton-backend.repl.co)
